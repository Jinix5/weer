---
name: Kinetic Obsidian
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#e6beb2'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#ad897e'
  outline-variant: '#5c4037'
  surface-tint: '#ffb59e'
  primary: '#ffb59e'
  on-primary: '#5e1700'
  primary-container: '#ff571a'
  on-primary-container: '#521300'
  inverse-primary: '#ae3200'
  secondary: '#fff3d2'
  on-secondary: '#3a3000'
  secondary-container: '#fdd400'
  on-secondary-container: '#6f5c00'
  tertiary: '#c8c6c5'
  on-tertiary: '#313030'
  tertiary-container: '#929090'
  on-tertiary-container: '#2a2a2a'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbd0'
  primary-fixed-dim: '#ffb59e'
  on-primary-fixed: '#3a0b00'
  on-primary-fixed-variant: '#852400'
  secondary-fixed: '#ffe170'
  secondary-fixed-dim: '#e9c400'
  on-secondary-fixed: '#221b00'
  on-secondary-fixed-variant: '#544600'
  tertiary-fixed: '#e5e2e1'
  tertiary-fixed-dim: '#c8c6c5'
  on-tertiary-fixed: '#1c1b1b'
  on-tertiary-fixed-variant: '#474746'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-xl:
    fontFamily: Space Grotesk
    fontSize: 96px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 64px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 32px
  margin-mobile: 20px
  margin-desktop: 80px
---

## Brand & Style

This design system is built for a premium AI agency that balances high-tech precision with human-centric creativity. The visual language is deeply rooted in **Glassmorphism** and **High-Contrast Bold** aesthetics, utilizing extreme depth and vibrant light sources to simulate a futuristic interface.

The brand personality is authoritative yet visionary. It evokes a sense of "intelligence in motion" through the use of blurred background elements and sharp foreground data points. The UI should feel like a high-end command center—sleek, responsive, and infinitely deep. Large-scale imagery and cinematic lighting are essential to ground the abstract AI concepts in a tangible, premium reality.

## Colors

The palette is anchored in a monochromatic "Obsidian" base to allow the vibrant accent "Glows" to pop with maximum intensity. 

- **Primary (Solar Flare):** A high-energy orange-red used for critical actions, highlights, and primary decorative gradients.
- **Secondary (Kinetic Yellow):** A sharp, technical yellow used for specific data callouts and secondary interactive states.
- **Backgrounds:** Utilize deep blacks (#050505) as the foundation, with layers of dark grays to define surface hierarchy.
- **Gradients:** Use radial and mesh gradients blending Solar Flare into the background to create atmospheric depth.

## Typography

The typography strategy emphasizes contrast between technical geometry and functional clarity.

- **Headlines:** Space Grotesk provides a cutting-edge, geometric feel. It should be used at large scales with tight tracking to create impact. All-caps treatments are encouraged for section headers.
- **Body Text:** Inter is selected for its exceptional readability in dark mode. It provides a neutral balance to the aggressive headline style.
- **Labels:** Small caps and increased letter-spacing on Space Grotesk should be used for metadata and technical indicators.

## Layout & Spacing

The layout follows a **Fluid Grid** model with generous margins to create a sense of cinematic "breathing room." 

- **Grid:** Use a 12-column grid for desktop. Elements should often overlap or "float" across grid lines to reinforce the glassmorphic depth.
- **Rhythm:** Spacing follows an 8px base unit. Vertical rhythm should be expansive between sections (120px+) to maintain a premium, editorial feel.
- **Density:** Keep interactive components high-density but wrap them in low-density containers to focus the user's eye.

## Elevation & Depth

Hierarchy is established through **Glassmorphism** and light-based layering rather than traditional drop shadows.

- **Surface Layers:** Use semi-transparent backgrounds (10-40% opacity) with a high backdrop-blur (20px-40px). 
- **Borders:** "Ghost borders" are essential—1px solid outlines with low opacity (white at 10-15%) that catch the light of background gradients.
- **Inner Glows:** Use subtle inner shadows or highlights on the top-left edges of cards to simulate a light source coming from the "screen."
- **Z-Index Strategy:** Active elements should "rise" by increasing background opacity and adding a subtle Solar Flare outer glow.

## Shapes

The shape language is sophisticated and modern. 

- **Radius:** Standard components utilize a 0.5rem (8px) radius. Large cards and sections utilize a more pronounced 1.5rem (24px) radius to soften the high-tech edge.
- **Buttons:** Primary buttons should be fully rounded (pill-shaped) to distinguish them from structural UI elements.
- **Containers:** Glassmorphic containers use sharp inner content but soft outer shells to create a nesting effect.

## Components

- **Buttons:** Primary buttons feature a solid Solar Flare fill with white text. Secondary buttons are glassmorphic with a 1px border and Kinnetic Yellow hover states.
- **Cards:** These are the core of the system. They must feature `backdrop-filter: blur()`, a 1px white-transparent border, and a very subtle radial gradient emanating from the cursor position on hover.
- **Inputs:** Dark, recessed fields with a 1px bottom border that transforms into a Solar Flare glow when focused.
- **Chips:** Small, technical labels with high letter-spacing and a secondary Kinetic Yellow accent dot.
- **Interactive Visualizers:** Custom components like "Cognitive Load" charts should use thin, vibrant lines and glowing nodes, mimicking the aesthetic of a high-end HUD (Heads-Up Display).